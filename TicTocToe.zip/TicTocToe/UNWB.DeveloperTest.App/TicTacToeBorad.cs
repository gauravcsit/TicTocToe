﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UNWB.DeveloperTest.App
{
    public class TicTacToeBorad
    {
        const int size = 4;
        int?[,] arrBoard;
        int player;

        public TicTacToeBorad()
        {
            arrBoard = new int?[size, size];
            player = 1;
        }

        public int CurrentPlayer()
        {
            return player + 1;
        }

        public void DisplayBoard()
        {
            Console.WriteLine();

            for (int i = 0; i < size; i++)
            {
                Console.Write("|");
                for (int j = 0; j < size; j++)
                {
                    switch (arrBoard[i, j])
                    {
                        case 0:
                            Console.Write(" O ");
                            break;
                        case 1:
                            Console.Write(" X ");
                            break;
                        default:
                            Console.Write("   ");
                            break;
                    };
                }

                Console.WriteLine("|");
            }

            Console.WriteLine();
        }

        public bool GetChanceFromPlayer(out int row, out int col)
        {
            bool Invalid = true;
            int number;

            Console.WriteLine("Player : {0} Take chance by entering Row and Colomn between 0 to 4", CurrentPlayer());

            Console.WriteLine("Row : ");
            do
            {
                string input = Console.ReadLine();

                Invalid = !Int32.TryParse(input, out number);

                if (Invalid)
                {
                    Console.WriteLine("Invalid Try again : ");
                }

            } while (Invalid);

            row = number;

            Console.WriteLine("Enter Colomn : ");
            do
            {
                string input = Console.ReadLine();

                Invalid = !Int32.TryParse(input, out number);

                if (Invalid)
                {
                    Console.WriteLine("Invalid Try again : ");
                }

            } while (Invalid);

            col = number;

            return true;
        }

        public bool CheckChane()
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (arrBoard[i, j] == null)
                    {
                        player = (player + 1) % 2;
                        return true;
                    }
                }
            }

            return false;
        }

        public bool TakeChanceAndReturnPlayer(int row, int col)
        {
            //check valid move
            if (row >= 0 && row < size && col >= 0 && col < size)
            {
                // check empty
                if (arrBoard[row, col] == null)
                {
                    arrBoard[row, col] = player;
                    return true;
                }
            }
            else
            {
                Console.WriteLine("Used Cell ! Try again");
            }

            return false;
        }

        public void DisplayWinner()
        {
            this.DisplayBoard();

            Console.WriteLine();
            Console.WriteLine("*** Congrats Player :{0} , you Win ***", CurrentPlayer());

            Console.ReadKey();
        }

        public void DisplayDraw()
        {
            this.DisplayBoard();

            Console.WriteLine();
            Console.WriteLine("** Game is Draw ***");

            Console.ReadKey();
        }

        public bool CheckWin()
        {

            for (int x = 0; x < size; x++)
            {
                //  Row
                if (arrBoard[x, 0] == player && arrBoard[x, 1] == player && arrBoard[x, 2] == player && arrBoard[x, 3] == player)
                    return true;

                //  Col
                if (arrBoard[0, x] == player && arrBoard[1, x] == player && arrBoard[2, x] == player && arrBoard[3, x] == player)
                    return true;
            }

            // Diagonal left
            if (arrBoard[0, 0] == player && arrBoard[1, 1] == player && arrBoard[2, 2] == player && arrBoard[3, 3] == player)
                return true;

            // Diagonal right
            if (arrBoard[0, 3] == player && arrBoard[1, 2] == player && arrBoard[2, 1] == player && arrBoard[3, 0] == player)
                return true;

            return false;
        }
    }
}
