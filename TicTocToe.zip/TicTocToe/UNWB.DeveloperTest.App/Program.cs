﻿using System;

namespace UNWB.DeveloperTest.App
{
    class Program
    {
        static void Main(string[] args)
        {
            TicTacToeBorad t = new TicTacToeBorad();

            Console.WriteLine("Hello Player 1 and 2 ! Get ready to start Tic Toc Toe game");

            while (true)
            {
                t.DisplayBoard();

                if (t.CheckChane())
                {
                    int row, col;
                    bool Invalid = true;
                    do
                    {
                        bool chane = t.GetChanceFromPlayer(out row, out col);
                        Invalid = ! t.TakeChanceAndReturnPlayer(row, col);
                    } while (Invalid);

                    if (t.CheckWin())
                    {
                        t.DisplayWinner();
                        break;
                    }
                }
                else
                {
                    t.DisplayDraw();
                    break;
                }
            }




        }
    }
}
